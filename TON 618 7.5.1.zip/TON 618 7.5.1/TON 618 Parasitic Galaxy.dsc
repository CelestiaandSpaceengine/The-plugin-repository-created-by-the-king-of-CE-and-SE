Galaxy "TON 618 Parasitic Galaxy"
{
        Type  "Sc"
        RA 0.8315733333333
        Dec 31.4772
        Distance 10800000
        Radius     120000
        AbsMag        -20.46
        Axis    [  0.4460   0.7450  -0.4961]
}